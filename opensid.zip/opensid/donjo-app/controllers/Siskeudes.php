<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Siskeudes extends Admin_Controller {
	private $filename = "import_data"; // Kita tentukan nama filenya
	
	public function __construct(){
		parent::__construct();
		$this->load->model('header_model');
		$this->load->model('SiskeudesModel');
		$this->controller = 'siskeudes';
		$this->modul_ini = 201;
		$this->submodul = 204;
	}
	
	public function index()
	{
		$data['siskeudes_master'] = $this->SiskeudesModel->view();
		$header = $this->header_model->get_data();
		$this->load->view('header', $header);
		$nav['act'] = 201;
		$nav['act_sub'] = $this->submodul;
		$this->load->view('nav', $nav);
		$this->load->view('siskeudes\view', $data);
		$this->load->view('footer');
	}
	
	public function form()
	{
		$data = array(); // Buat variabel $data sebagai array
		
		if(isset($_POST['preview'])){ // Jika user menekan tombol Preview pada form
			// lakukan upload file dengan memanggil function upload yang ada di SiskeudesModel.php
			$upload = $this->SiskeudesModel->upload_file($this->filename);
			
			if($upload['result'] == "success"){ // Jika proses upload sukses
				// Load plugin PHPExcel nya
				include APPPATH.'third_party/PHPExcel/PHPExcel.php';
				
				$excelreader = new PHPExcel_Reader_Excel2007();
				$loadexcel = $excelreader->load('excel/'.$this->filename.'.xlsx'); // Load file yang tadi diupload ke folder excel
				$sheet = $loadexcel->getActiveSheet()->toArray(null, true, true ,true);
				
				// Masukan variabel $sheet ke dalam array data yang nantinya akan di kirim ke file form.php
				// Variabel $sheet tersebut berisi data-data yang sudah diinput di dalam excel yang sudha di upload sebelumnya
				$data['sheet'] = $sheet; 
			}else{ // Jika proses upload gagal
				$data['upload_error'] = $upload['error']; // Ambil pesan error uploadnya untuk dikirim ke file form dan ditampilkan
			}
		}
		$header = $this->header_model->get_data();
		$this->load->view('header', $header);
		$nav['act'] = 201;
		$nav['act_sub'] = 204;
		$this->load->view('nav', $nav);
		$this->load->view('siskeudes\form', $data);
		$this->load->view('footer');
	}
	
	
	// Tampilkan detail laporan siskeudes. filter berdasarkan id_master nya. 
	public function laporan()
	{
		$header = $this->header_model->get_data();
		$this->load->view('header', $header);
		$nav['act'] = 201;
		$nav['act_sub'] = 204;
		$this->load->view('nav', $nav);
		$data['siskeudes'] = $this->SiskeudesModel->laporan();
		$this->load->view('siskeudes\laporan', $data);
		$this->load->view('footer');
	}

	
	public function import()
	{
		$tahun			= $this->input->post('tahun');
		$jenis			= $this->input->post('jenis');
		// $tanggallaporan	= $this->input->post('tanggallaporan')

		$master_data	= array(
			'tahun_anggaran'=> $tahun,
			'jenis'			=> $jenis
		);


		// Load plugin PHPExcel nya
		include APPPATH.'third_party/PHPExcel/PHPExcel.php';
		
		$excelreader = new PHPExcel_Reader_Excel2007();
		$loadexcel = $excelreader->load('excel/'.$this->filename.'.xlsx'); // Load file yang telah diupload ke folder excel
		$sheet = $loadexcel->getActiveSheet()->toArray(null, true, true ,true);
		
		// Buat sebuah variabel array untuk menampung array data yg akan kita insert ke database
		$data = array();
		

		$numrow = 1;
		foreach($sheet as $row){
			// Cek $numrow apakah lebih dari 1
			// Artinya karena baris pertama adalah nama-nama kolom
			// Jadi dilewat saja, tidak usah diimport
			if($numrow > 1){

				// Kita push (add) array data ke variabel data
				array_push($data, array(
					'tahun_anggaran'=>$tahun,
					'jenis'=>$jenis,
					'kode_rek_1'=>$row['A'], // Insert data kode rek 1 dari kolom A di excel
					'kode_rek_2'=>$row['B'], // Insert data kode rek 2 dari kolom B di excel
					'uraian'=>$row['C'], // Insert data uraian APBDes dari kolom C di excel
					'anggaran'=>$row['D'], // Insert data Anggaran Kegiatan dari kolom D di excel
					'realisasi'=>$row['E'],// Insert data realisasi anggaran dari kolom E di excel
					'saldo'=>$row['F']// Insert data saldo lebih/kurang dari kolom F di excel
				));
			}
			
			$numrow++; // Tambah 1 setiap kali looping
		}

		$this->SiskeudesModel->insert_master($master_data);

		// Panggil fungsi insert_multiple yg telah kita buat sebelumnya di model
		$this->SiskeudesModel->insert_multiple($data);
		
		redirect("Siskeudes"); // Redirect ke halaman awal (ke controller siskeudes fungsi index)
	}
	public function hapus(){
		
	}
}

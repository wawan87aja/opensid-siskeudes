<?php
class Migrasi_2002_ke_2003 extends CI_model {

	public function up()
	{
		$this->laporan_siskeudes();
		// Hapus setting tombol cetak surat langsung
		$this->db->where('key', 'tombol_cetak_surat')
			->delete('setting_aplikasi');
		// Setting nilai default supaya tidak error pada sql strict mode
		$fields = array();
		$fields['parrent'] = array('type' => 'INT', 'constraint' => 4, 'default' => 0);
		$fields['tipe'] = array('type' => 'INT', 'constraint' => 4, 'default' => 0);
	  $this->dbforge->modify_column('gambar_gallery', $fields);
		$fields = array();
		$fields['kode_surat'] = array('type' => 'VARCHAR', 'constraint' => 10, 'null' => TRUE, 'default' => NULL);
	  $this->dbforge->modify_column('tweb_surat_format', $fields);
		// Tambah kolom hits pada artikel
		if (!$this->db->field_exists('hit','artikel'))
		{
			$this->db->query("ALTER TABLE artikel ADD COLUMN hit INT NULL DEFAULT '0'");
		}
		// Tambah Modul Pengunjung pada Admin WEB
		$data = array(
				'id' => 205,
				'modul' => 'Pengunjung',
				'url' => 'pengunjung/clear',
				'aktif' => 1,
				'ikon' => 'fa-bar-chart',
				'urut' => 10,
				'level' => 4,
				'hidden' => 0,
				'ikon_kecil' => '',
				'parent' => 13
				);
		$sql = $this->db->insert_string('setting_modul', $data);
		$sql .= " ON DUPLICATE KEY UPDATE
				modul = VALUES(modul),
				aktif = VALUES(aktif),
				ikon = VALUES(ikon),
				urut = VALUES(urut),
				level = VALUES(level),
				hidden = VALUES(hidden),
				ikon_kecil = VALUES(ikon_kecil),
				parent = VALUES(parent)
				";
		$this->db->query($sql);
	}

	
// berikut merupakan fungsi untuk migrasi laporan siskeudes yang saya kembangkan dari tree laporan siskeudes
	public function laporan_siskeudes(){
	$this->db->where('id', 203)->update('setting_modul', array('modul'=>'Laporan Transparansi'));
  	// Tambah menu teks berjalan
		$data = array(
			'id' => '204',
			'modul' => 'Laporan Siskeudes',
			'url' => 'siskeudes',
			'aktif' => '1',
			'ikon' => 'fa-file-text',
			'urut' => '6',
			'level' => '2',
			'parent' => '201',
			'hidden' => '0',
			'ikon_kecil' => 'fa-file-text'
		);
		$sql = $this->db->insert_string('setting_modul', $data) . " ON DUPLICATE KEY UPDATE url = VALUES(url), ikon = VALUES(ikon), modul = VALUES(modul)";
		$this->db->query($sql);

		// Tambah tabel siskeudes_master
		if (!$this->db->table_exists('siskeudes_master') )
		{
			$query = "
			CREATE TABLE IF NOT EXISTS `siskeudes_master` (
				 `id` INT(3) NOT NULL AUTO_INCREMENT ,
				 `tahun_anggaran` VARCHAR(4) NOT NULL , 
				 `jenis` VARCHAR(4) NOT NULL ,
				 `tanggal_realisasi` DATE NOT NULL , 
				 PRIMARY KEY (`id`)
			)";
			$this->db->query($query);
		}

		// Tambah tabel siskeudes untuk menyimpan seluruh data hasil impor excel
		if (!$this->db->table_exists('siskeudes') )
		{
			$query = "
			CREATE TABLE IF NOT EXISTS `siskeudes` (
				`id` INT(3) NOT NULL AUTO_INCREMENT , 
				`tahun_anggaran` VARCHAR(4) NOT NULL , 
				`jenis` VARCHAR(4) NOT NULL ,
				`kode_rek_1` VARCHAR(10) NOT NULL , 
				`kode_rek_2` VARCHAR(10) NOT NULL , 
				`uraian` VARCHAR(200) NOT NULL , 
				`anggaran` VARCHAR(10) NOT NULL , 
				`realisasi` VARCHAR(10) NOT NULL , 
				`saldo` VARCHAR(10) NOT NULL , 
				PRIMARY KEY (`id`)
			)";
			$this->db->query($query);
		}

		// $sql = $this->db->insert_string('siskeudes') . "ALTER TABLE `siskeudes` ADD CONSTRAINT `id_master` FOREIGN KEY (`id_master`) REFERENCES `siskeudes_master`(`id_master`) ON DELETE CASCADE ON UPDATE CASCADE";
		// $this->db->query($sql);
	}
}

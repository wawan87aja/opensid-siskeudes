	<div class="content-wrapper">
		<section class="content-header">
			<h1>Daftar Laporan Siskeudes</h1>
			<ol class="breadcrumb">
				<li><a href="<?=site_url('hom_sid')?>"><i class="fa fa-home"></i> Home</a></li>
	      		<li><a href="<?=site_url('Siskeudes/index')?>"></i> Laporan Siskeudes</a></li>
			</ol>
		</section>
		<section class="content" id="maincontent">
		<div class="row">
			<div class="col-sm-12">
				<div class="box box-danger">
					<div class="box-body">
						<div class="col-sm-6">
							<div class="form-group">
								<div class="input-group input-group-sm">
									<a href="<?php echo base_url("Siskeudes/form"); ?>" class="btn btn-info btn-flat btn-sm" role="button" aria-pressed="true">Import Data</a>
									
								</div>
							</div>
						</div>
					</div>
					<hr>
					<div class="row">
						<div class="col-sm-12">
							<h4 class="text-center"><strong>DAFTAR DATA SISKEUDES</strong></h4>
							<div class="table-responsive">
								<table class="table table-bordered table-striped dataTable table-hover nowrap" border="1" cellpadding="10">
									<thead class="bg-gray disabled color-palette" >
										<tr>
											<th>TAHUN ANGGARAN</th> 
											<!-- jenis Laporan dibedakan antara APBDes Awal dan PAK -->
											<th>JENIS APBDESA</th> 
											<!-- untuk info/footer laporan ('realisasi sampai dengan...') -->
											<th>TANGGAL REALISASI</th> 
											<th colspan="2">AKSI</th>
										</tr>
									</thead>
									<tbody>
										<?php foreach($siskeudes_master as $master): ?>
											<tr>
												
												<td><?php echo $master->tahun_anggaran ?></td>
												<td><?php echo $master->jenis ?></td>
												<td><?php echo $master->tanggal_realisasi ?></td>
												<td><?php echo anchor('siskeudes/hapus'.$master->tahun,'<div class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></div>' ) ?></td>
												<!-- tambahkan filter di sini untuk menampilkan hanya data tabel siskeudes yang tahun anggaran dan jenis-nya sama dengan id tabel siskeudes master -->
												<td><a href="<?php echo base_url("Siskeudes/laporan"); ?>"class="btn btn-success btn-flat btn-sm" role="button" aria-pressed="true"><i class="fa fa-search"></i></a></td>
											</tr>
										<?php endforeach; ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>	

											
					<!-- untuk sementara tombol untuk melihat detail laporan disimpan di sini, tapi seharusnya nanti tombol ini disimpan di kolom aksi untuk setiap data di tabel siskeudes_master, bersamaan dengan tombol hapus -->
					<!-- <a href="<?php echo base_url("Siskeudes/laporan"); ?>">Detail Laporan</a><br><br>-->

					

		
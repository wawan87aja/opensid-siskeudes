<!-- ========================================================================================
halaman ini bisa dikembangkan untuk menampilkan APBDes awal, dan APBDes PAK
	1. untuk APBDes awal, tinggal mengambil data APBDes berdasarkan data siskeudes master yang memiliki jenis awal dan menyembunyikan kolom realisasi, dan saldo
	2. untuk APBDes PAK, tampilkan data berdasarkan data siskeudes_master yang memiliki tahun yang sama. 
	- (a)kolom anggaran 'semula' diisi data yang memiliki jenis awal, 
	- (b)kolom anggaran 'menjadi' diisi data yang memiliki jenis PAK,
	- kolom 'Bertambah/(berkurang)' diisi fungsi aritmatika (b)-(a)
=============================================================================================
 -->

	<div class="content-wrapper">
		<section class="content-header">
			<h1>Laporan Siskeudes</h1>
			<ol class="breadcrumb">
				<li><a href="<?= site_url('hom_sid')?>"><i class="fa fa-home"></i> Home</a></li>
				<li class="active">Detail Laporan Siskeudes</li>
			</ol>
		</section><br>
			<div class="box box-info">
		<div class="box-header with-border">
			<a href="<?php echo base_url("Siskeudes"); ?>" class="btn btn-info btn-flat btn-sm" role="button" aria-pressed="true">Kembali</a>
			<a href="" class="btn btn-success btn-flat btn-sm" role="button" aria-pressed="true">Cetak</a><br><br>
			<table id="judul-laporan" width="100%" style="border: solid 0px black; text-align: center;">
				<tr>
					<td>
						<h4>LAPORAN REALISASI PELAKSANAAN</h4>
						<h4>ANGGARAN PENDAPATAN DAN BELANJA DESA</h4>
						<h4>PEMERINTAH <?= strtoupper(ucwords($this->setting->sebutan_desa))?> <?= strtoupper($desa['nama_desa'])?></h4>
						<!-- <h4>SEMESTER <?= $sm ?></h4> -->
						<h4>TAHUN ANGGARAN <?= $ta ?></h4>
					</td>
				</tr>

			</table><br>
			<p style="text-align: right;">Realisasi sampai dengan : <!-- (isi data tanggal realisasi dari tabel siskeudes_master) --></p>
			<table width="100%"  border="1" cellpadding="8">
				<thead  style="text-align: center; font-weight: bolder; background-color: #AAA;">
					<trtr>
						<td colspan="2"><p>KODE REK</p></td>
						<td rowspan="2">URAIAN</td>
						<td rowspan="2"><p>ANGGARAN</p><p>(Rp)</p></td>
						<td rowspan="2"><p>REALISASI</p><p>(Rp)</p></td>
						<td rowspan="2"><p>LEBIH/ (KURANG)</p><p>(Rp)</p></td>
					</tr>
					<trtr>
						<td>1</td>
						<td>2</td>
					</tr>
					<trtr>
						<td>1</td>
						<td>2</td>
						<td>3</td>
						<td>4</td>
						<td>5</td>
						<td>6</td>
					</tr>
					<tr>
				</thead>
				<tbody>
					<?php foreach($siskeudes as $data) : ?>
						<!-- lakukan filter untuk menampilkan data pendapatan yang kode_rek_2 nya diawali dengan 4
						tambahkan baris 'jumlah pendapatan' lalu  jumlahkan semua variabel $x, $y, dan $z, filter yang kode_rek_2 nya diawali dengan 4. buat variabel $a,$b, dan $c untuk menyimpan masing-masing nilainya

						lakukan filter untuk menampilkan data belanja yang kode_rek_1 nya bukan 0
						tambahkan baris 'JUMLAH BELANJA', lalu jumlahkan semua variabel $x, $y, dan $z, yang kode_rek_2 nya diawali dengan 5. buat variabel $e,$f, dan $g untuk menyimpan masing-masing nilainya
						
						tambahkan baris 'surplus/(defisit)' lalu buat variabel $h=$a-$e, $i=$b-$f, $j=$c-$g

						lakukan filter untuk menampilkan data pembiayaan yang kode_rek_2 nya diawali dengan 6
						tambahkan baris 'PEMBIAYAAN NETTO', jumlahkan semua variabel $x, $y, dan $z, filter yang kode_rek_2 nya diawali dengan 6.buat variabel $k,$l, dan $m untuk menyimpan masing-masing nilainya

						tambahkan baris 'sisa lebih/(kurang) pembiayaan anggaran lalu buat variabel $o=$h+$k, $p=$i-$l , $q=$j-$m' -->
						<tr>
							<td><?php echo $data->kode_rek_1; ?></td>
							<td><?php echo $data->kode_rek_2; ?></td>
							<td><?php echo $data->uraian; ?></td>
							<td style="text-align: right;"><?php echo $data->anggaran; ?></td>
							<td style="text-align: right;"><?php echo $data->realisasi; ?></td>
							<td style="text-align: right;"><?php echo $data->saldo; ?></td>
						</tr> 
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	</div>
</div>


		


		




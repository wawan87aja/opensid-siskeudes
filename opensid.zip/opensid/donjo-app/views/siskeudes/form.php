<div class="content-wrapper">
	<div class="content">
		<section class="content-header">
			<h3>Form Import</h3>
			<ol class="breadcrumb">
				<li><a href="<?= site_url('hom_sid')?>"><i class="fa fa-home"></i> Home</a></li>
				<li class="active">Import Data Siskeudes</li>
			</ol>
		</section>
		<section class="content" id="maincontent">
			<div class="row">
					<div class="col-sm-12">
						<div class="box box-danger">
							<div class="box-body">
									<form >
										<div class='modal-body'>
											<a href="<?php echo base_url("Siskeudes"); ?>" class="btn btn-info btn-flat btn-sm" role="button" aria-pressed="true">Kembali</a>
											<a href="<?php echo base_url("excel/format1.xlsx"); ?>" class="btn btn-warning btn-flat btn-sm" role="button" aria-pressed="true">Download Format</a>
										</div>
									</form>
								<form>
								  
							</form>
								<!-- Buat sebuah tag form dan arahkan action nya ke controller ini lagi -->
								<form class="form-group row" method="post" action="<?php echo base_url("Siskeudes/form"); ?>" enctype="multipart/form-data">
									<!--
									-- Buat sebuah input type file
									-- class pull-left berfungsi agar file input berada di sebelah kiri
									-->

									<input class="col-sm-4 " type="file" name="file">

									<!--
									-- BUat sebuah tombol submit untuk melakukan preview terlebih dahulu data yang akan di import
									-->
									<input  type="submit" name="preview" value="Preview">
								</form>

								<?php
								if(isset($_POST['preview'])){ // Jika user menekan tombol Preview pada form
									if(isset($upload_error)){ // Jika proses upload gagal
										echo "<div style='color: red;'>".$upload_error."</div>"; // Muncul pesan error upload
										die; // stop skrip
									}

									// Buat sebuah tag form untuk proses import data ke database
									echo "<form method='post' action='".base_url("index.php/Siskeudes/import")."'>";

									// Buat sebuah div untuk alert validasi kosong
									echo "<div style='color: red;' id='kosong'>
									Semua data belum diisi, Ada <span id='jumlah_kosong'></span> data yang belum diisi.
									</div>";
									?>
									<!-- isian berikut perlu divalidasi agar wajib diisi. karena datanya akan dimas -->
								<div class="form-group">
								    <label for="tahun_anggaran">Tahun Anggaran</label>
								    <input type="text" name="tahun" class="form-control" placeholder="Tahun Anggaran">
								</div>
								  <div class="form-group">
								    <label for="exampleFormControlSelect1">Jenis APBDesa</label>
								    <select class="form-control" name="jenis" id="exampleFormControlSelect1">
								      <option>Awal</option>
								      <option>PAK</option>
								     </select>
								  </div>
								  
								<div class='form-group'>
									<label for="tanggallaporan">Tanggal Laporan Realisasi</label>
									<div class="input-group input-group-sm date">
										<div class="input-group-addon">
											<i class="fa fa-calendar"></i>
										</div>
										<input class="form-control input-sm pull-right" id="tgl_1" name="tanggallaporan" type="text">
									</div>
								</div>

									<?php 

									echo "<table border='1' cellpadding='8' width='100%'>
									
									<tr>
										<th>Kode Rek 1</th>
										<th>Kode Rek 2</th>
										<th>Uraian</th>
										<th>Anggaran</th>
										<th>Realisasi</th>
										<th>Saldo</th>
									</tr>";

									$numrow = 1;
									$kosong = 0;

									// Lakukan perulangan dari data yang ada di excel
									// $sheet adalah variabel yang dikirim dari controller
									foreach($sheet as $row){
										// Ambil data pada excel sesuai Kolom
										$kode_rek_1 = $row['A']; // Ambil data Kode rek 1
										$kode_rek_2 = $row['B']; // Ambil data kode rek 2
										$uraian = $row['C']; // Ambil data jenis uraian
										$anggaran = $row['D']; // Ambil data anggaran
										$realisasi = $row['E']; // Ambil data uraian
										$saldo = $row['F']; // Ambil data saldo

										// Cek jika semua data tidak diisi
										if($kode_rek_1 == "" && $kode_rek_2 == "" && $uraian == "" && $anggaran == "" && $realisasi== "" && $saldo == "")
											continue; // Lewat data pada baris ini (masuk ke looping selanjutnya / baris selanjutnya)
												// Cek $numrow apakah lebih dari 1
												// Artinya karena baris pertama adalah nama-nama kolom
												// Jadi dilewat saja, tidak usah diimport

										// ini merupakan contoh validasi contekkan dari mynotescode.com
										// validasinya harus diubah agar kolom anggara, realisasi dan saldo hanya menerima data berupa angka, agar nantinya dapat menggunakan fungsi aritmatika dalam form laporan, grafik, dll

												if($numrow > 1){
													// Validasi apakah semua data telah diisi
													$kode_rek_1_td = ( ! empty($kode_rek_1))? "" : " style='background: #E07171;'"; // Jika kode rek 1 kosong, beri warna merah
													$kode_rek_2_td = ( ! empty($kode_rek_2))? "" : " style='background: #E07171;'"; // Jika kode rek 2 kosong, beri warna merah
													$uraian_td = ( ! empty($uraian))? "" : " style='background: #E07171;'"; // Jika uraian, beri warna merah
													$anggaran_td = ( ! empty($anggaran))? "" : " style='background: #E07171;'"; // Jika anggaran kosong, beri warna merah
													$realisasi_td = ( ! empty($realisasi))? "" : " style='background: #E07171;'"; // Jika realisasi kosong, beri warna merah
													$saldo_td = ( ! empty($saldo))? "" : " style='background: #E07171;'"; // Jika saldo kosong, beri warna merah

													// Jika salah satu data ada yang kosong
													if($kode_rek_1 == "" or $kode_rek_2 == "" or $uraian == "" or $anggaran == "" && $realisasi== "" && $saldo == ""){
														$kosong++; // Tambah 1 variabel $kosong
													}

													echo "<tr>";
													echo "<td".$kode_rek_1_td.">".$kode_rek_1."</td>";
													echo "<td".$kode_rek_2_td.">".$kode_rek_2."</td>";
													echo "<td".$uraian_td.">".$uraian."</td>";
													echo "<td".$anggaran_td.">".$anggaran."</td>";
													echo "<td".$realisasi_td.">".$realisasi."</td>";
													echo "<td".$saldo_td.">".$saldo."</td>";
													echo "</tr>";
												}

												$numrow++; // Tambah 1 setiap kali looping
											}

											echo "</table>";

											// Cek apakah variabel kosong lebih dari 0
											// Jika lebih dari 0, berarti ada data yang masih kosong
											if($kosong > 0){
											?>

								<script>
									$(document).ready(function(){
										// Ubah isi dari tag span dengan id jumlah_kosong dengan isi dari variabel kosong
										$("#jumlah_kosong").html('<?php echo $kosong; ?>');

										$("#kosong").show(); // Munculkan alert validasi kosong
									});
								</script>

								<?php
									}else{ // Jika semua data sudah diisi
										echo "<hr>";

										// Buat sebuah tombol untuk mengimport data ke database
										echo "<button type='submit' name='import'>Import</button>";
										echo "<a href='".base_url("Siskeudes")."'>Cancel</a>";
									}
									echo "</form>";
									}
								?>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>
	</div>
</div>


				